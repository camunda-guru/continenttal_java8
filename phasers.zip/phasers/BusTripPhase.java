package com.cts.phasers;

import java.util.concurrent.Phaser;

public class BusTripPhase {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Phaser phaser = new Phaser(3);
	        Bus f1 = new Bus(phaser, "Bus 1");
	        Bus f2 = new Bus(phaser, "Bus 2");
	        Bus f3 = new Bus(phaser, "Bus 3");
	        f1.start();
	        f2.start();
	        f3.start();
	}

}
