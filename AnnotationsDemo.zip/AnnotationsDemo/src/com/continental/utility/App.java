package com.continental.utility;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

import com.continental.annotations.AccountType;
import com.continental.annotations.Log;
import com.continental.annotations.Types;
import com.continental.models.CustomerAccount;
import com.continental.models.Product;

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Product product =new Product();
        product.setProductId(-10);
        System.out.println(product.hashCode());
       System.out.println(System.identityHashCode(product));
       
       CustomerAccount ca =new CustomerAccount();
       ca.setActNo(5984345);
       ca.setActType(Types.SAVING);
       ca.setBalance(3596563);
       
      Field[] flds= CustomerAccount.class.getDeclaredFields();
      
      System.out.println(flds.length);
      for(Field fld : flds)
      {
    	
    	 AccountType act= fld.getAnnotation(AccountType.class);
    	 if(act!=null)
    	 {
    	   System.out.println(act.assignedType());
    	   if(act.assignedType().equals(ca.getActType()))
    		   System.out.println("Object can be saved");
    	   
    	 }
    	 
      }
      
      //read method level annotations
      
      Method[] methods = Product.class.getDeclaredMethods();
      for(Method method : methods)
      {
    	 
    	  if(method.isAnnotationPresent(Log.class))
    	  {
    		 Annotation[]  annotations= method.getAnnotations();
    		  
    		 for(Annotation ann : annotations)
    		 {
    			 Log log = (Log) ann;
    			 System.out.println(log.comments());
    			 System.out.println(log.date());
    		 }
    		 
    	  }
    	  
      }
      
    //class level Annotations
      
    Class<Product> classInfo =   Product.class;
    Log[] annotations= classInfo.getAnnotationsByType(Log.class);
    
    for(Log log : annotations)
    {
    	System.out.println(log.comments());
    }
    
      
       
	}

}
