package com.continental.annotations;

public enum Types {
SAVING,RECURRING,DEMAT,LOAN
}
