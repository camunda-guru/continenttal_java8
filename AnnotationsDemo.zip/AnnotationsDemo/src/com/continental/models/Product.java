package com.continental.models;

import com.continental.annotations.Log;

@Log(date="7/11/2017",comments="Class level log")
@Log(date="7/11/2017",comments="Created By Parameswari")
@Log(date="7/11/2017",comments="For Continental Training")
public class Product {
	@Log(date="7/11/2017",comments="Field level log")
	private int productId;
	private String productName;
	public int getProductId() {
		return productId;
	}
	@Log(date="7/11/2017",comments="Method level log")
	public void setProductId(int productId) {
		@Log(date="7/11/2017",comments="Local variable level log")
		boolean flag=false;
		
		if(TestProductId(productId))
		  this.productId = productId;
		else
			this.productId=0;
		
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	
	@Deprecated
	public boolean TestProductId(int productId)
	{
		if (productId>0)
		  return true;
		else
			return false;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + productId;
		result = prime * result + ((productName == null) ? 0 : productName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Product other = (Product) obj;
		if (productId != other.productId)
			return false;
		if (productName == null) {
			if (other.productName != null)
				return false;
		} else if (!productName.equals(other.productName))
			return false;
		return true;
	}
	
	
	
}
