package com.continental.models;

import com.continental.annotations.AccountType;
import com.continental.annotations.Types;

public class CustomerAccount {

	private int actNo;
	@AccountType(assignedType=Types.SAVING)
	private Types actType;
	public Types getActType() {
		return actType;
	}
	public void setActType(Types actType) {
		this.actType = actType;
	}
	private long balance;
	public int getActNo() {
		return actNo;
	}
	public void setActNo(int actNo) {
		this.actNo = actNo;
	}
	
	public long getBalance() {
		return balance;
	}
	public void setBalance(long balance) {
		this.balance = balance;
	}
	
	
	
}
