package com.cts.latches;

import java.util.concurrent.CountDownLatch;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SampleThread implements  Runnable{
	private final String name;
    private final int timeToStart;
    private final CountDownLatch latch;
  
    public SampleThread(String name, int timeToStart, CountDownLatch latch){
        this.name = name;
        this.timeToStart = timeToStart;
        this.latch = latch;
    }
  
    @Override
    public void run() {
        try {
            Thread.sleep(timeToStart);
        } catch (InterruptedException ex) {
            Logger.getLogger(SampleThread.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println( name + " is Up");
        System.out.println(latch.getCount());
        latch.countDown(); //reduce count of CountDownLatch by 1
    }
  



}
