package com.cts.cyclicbarriers.vip;

import java.util.concurrent.CyclicBarrier;

public class DarshanApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 // No.of threads to wait
        // In general terms, no.of queues to wait
        // here 2
        CyclicBarrier cb=new CyclicBarrier(2,new GoVIP());
            
        // Create two threads,
        // a 50/- line and a 100/- line
        new FiftyClass(cb,"fifty");
        new HundredClass(cb,"hundred");
	}

}
